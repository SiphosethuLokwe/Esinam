<?php

class AccountUID{
    var $Id;
    var $AccountId;
    var $CreatedDate;

    public function __construct(){

    }
}
?>